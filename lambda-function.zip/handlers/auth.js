"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authHandler = void 0;
const authHandler = (req, res) => {
    const accessToken = req.query.accessToken;
    if (accessToken) {
        return res.status(200).json(true);
    }
    else {
        return res.status(401).json({ error: "Unauthorized" });
    }
};
exports.authHandler = authHandler;
