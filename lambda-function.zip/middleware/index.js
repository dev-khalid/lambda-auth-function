"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.checkAccessToken = void 0;
const checkAccessToken = (req, res) => {
    const accessToken = req.query.accessToken;
    if (accessToken) {
        return res.json(true);
    }
    else {
        return res.status(401).json({ error: 'Unauthorized' });
    }
};
exports.checkAccessToken = checkAccessToken;
